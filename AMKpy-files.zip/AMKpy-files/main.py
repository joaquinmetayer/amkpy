'''AMKpy
   Powerful auto mouse click and keyboard type in python.
   
   https://joaquinmetayer.github.io/amkpy/
   https://github.com/joaquinmetayer/amkpy'''

#imports
import pyautogui
import time

#get size
print(pyautogui.size())

#click - X and Y
#pyautogui.click(70, 40)

#time to sleep
#time.sleep(5)

#write
#pyautogui.typewrite('writing hello!!!')

#hotkey
#pyautogui.hotkey('return')

#scroll down and up
#pyautogui.scroll(-500)
#pyautogui.scroll(500)